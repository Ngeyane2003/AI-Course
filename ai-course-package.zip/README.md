# AI Course Project

This repository contains two complete courses:
1. AI for Everyone
2. AI for Business

Each course includes:
- Full detailed notes
- Slide summaries
- Voiceover scripts for TTS
- Canva/PPTX slide files
- Ready-to-deploy HTML pages

Deploy with GitHub Pages by uploading all files.
